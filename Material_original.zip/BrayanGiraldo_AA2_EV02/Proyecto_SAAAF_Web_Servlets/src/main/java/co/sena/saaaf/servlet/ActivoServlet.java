package co.sena.saaaf.servlet;

import co.sena.saaaf.dao.ActivoDAO;
import co.sena.saaaf.model.Activo;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;

/**
 * Servlet del modulo Gestion de Activos.
 * Implementa uso de metodos GET y POST para el CRUD del sistema SAAAF.
 */
@WebServlet(name = "ActivoServlet", urlPatterns = {"/activos"})
public class ActivoServlet extends HttpServlet {

    private final ActivoDAO activoDAO = new ActivoDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String accion = obtenerAccion(request);
        try {
            switch (accion) {
                case "nuevo":
                    mostrarFormulario(request, response, null);
                    break;
                case "editar":
                    editarActivo(request, response);
                    break;
                case "eliminar":
                    eliminarActivo(request, response);
                    break;
                default:
                    listarActivos(request, response);
                    break;
            }
        } catch (SQLException exception) {
            throw new ServletException("Error procesando la solicitud GET de activos", exception);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String accion = obtenerAccion(request);
        try {
            if ("actualizar".equals(accion)) {
                actualizarActivo(request, response);
            } else {
                insertarActivo(request, response);
            }
        } catch (SQLException exception) {
            throw new ServletException("Error procesando la solicitud POST de activos", exception);
        }
    }

    private String obtenerAccion(HttpServletRequest request) {
        String accion = request.getParameter("accion");
        return accion == null ? "listar" : accion;
    }

    private void listarActivos(HttpServletRequest request, HttpServletResponse response) throws SQLException, ServletException, IOException {
        request.setAttribute("activos", activoDAO.listarActivos());
        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/activos.jsp");
        dispatcher.forward(request, response);
    }

    private void mostrarFormulario(HttpServletRequest request, HttpServletResponse response, Activo activo) throws ServletException, IOException {
        request.setAttribute("activo", activo);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/form-activo.jsp");
        dispatcher.forward(request, response);
    }

    private void editarActivo(HttpServletRequest request, HttpServletResponse response) throws SQLException, ServletException, IOException {
        int idActivo = Integer.parseInt(request.getParameter("id"));
        Activo activo = activoDAO.buscarPorId(idActivo);
        mostrarFormulario(request, response, activo);
    }

    private void insertarActivo(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
        Activo activo = construirActivoDesdeRequest(request);
        activoDAO.insertarActivo(activo);
        response.sendRedirect("activos?mensaje=registrado");
    }

    private void actualizarActivo(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
        Activo activo = construirActivoDesdeRequest(request);
        activo.setIdActivo(Integer.parseInt(request.getParameter("idActivo")));
        activoDAO.actualizarActivo(activo);
        response.sendRedirect("activos?mensaje=actualizado");
    }

    private void eliminarActivo(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
        int idActivo = Integer.parseInt(request.getParameter("id"));
        activoDAO.eliminarActivo(idActivo);
        response.sendRedirect("activos?mensaje=eliminado");
    }

    private Activo construirActivoDesdeRequest(HttpServletRequest request) {
        Activo activo = new Activo();
        activo.setCodigoActivo(request.getParameter("codigoActivo"));
        activo.setNombreActivo(request.getParameter("nombreActivo"));
        activo.setTipoActivo(request.getParameter("tipoActivo"));
        activo.setArea(request.getParameter("area"));
        activo.setResponsable(request.getParameter("responsable"));
        activo.setEstado(request.getParameter("estado"));
        activo.setFechaRegistro(LocalDate.parse(request.getParameter("fechaRegistro")));
        activo.setObservaciones(request.getParameter("observaciones"));
        return activo;
    }
}
