package co.sena.saaaf.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Clase responsable de centralizar la conexion JDBC del sistema SAAAF.
 */
public class ConexionJDBC {

    private static final String URL = "jdbc:mysql://localhost:3306/saaaf_db?useSSL=false&serverTimezone=UTC";
    private static final String USUARIO = "root";
    private static final String CLAVE = "";

    private ConexionJDBC() {
        // Constructor privado para evitar instancias.
    }

    public static Connection obtenerConexion() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(URL, USUARIO, CLAVE);
        } catch (ClassNotFoundException exception) {
            throw new SQLException("No se encontro el driver JDBC de MySQL", exception);
        }
    }
}
