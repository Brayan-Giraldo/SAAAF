# Pruebas funcionales del módulo web SAAAF

## Prueba 1 - Listar activos con método GET
- URL: `http://localhost:8080/saaaf-web/activos`
- Resultado esperado: se muestra la tabla de activos cargada desde MySQL mediante JDBC.

## Prueba 2 - Registrar activo con método POST
- URL: `http://localhost:8080/saaaf-web/registro-activo.html`
- Acción: diligenciar formulario HTML y enviar.
- Resultado esperado: el servlet recibe parámetros con `request.getParameter()` e inserta el registro.

## Prueba 3 - Editar activo
- URL: `http://localhost:8080/saaaf-web/activos?accion=editar&id=1`
- Resultado esperado: el JSP muestra el formulario con datos cargados desde la base de datos.

## Prueba 4 - Eliminar activo
- URL: `http://localhost:8080/saaaf-web/activos?accion=eliminar&id=1`
- Resultado esperado: se elimina el activo y se redirecciona al listado.

## Prueba 5 - Dashboard
- URL: `http://localhost:8080/saaaf-web/dashboard`
- Resultado esperado: se observan indicadores de total, disponibles, asignados y mantenimiento.
