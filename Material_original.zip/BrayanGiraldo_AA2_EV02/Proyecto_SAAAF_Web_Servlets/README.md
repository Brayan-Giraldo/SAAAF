# Proyecto SAAAF Web Servlets - GA7-220501096-AA2-EV02

Este proyecto corresponde a la evidencia **Módulos de software codificados y probados**.

## Tecnologías utilizadas

- Java 11 o superior
- Servlets Java
- JSP
- JDBC
- MySQL
- HTML5
- CSS3
- JavaScript
- Git / GitHub
- Apache Tomcat 9

## Módulo implementado

Módulo: **Gestión de Activos Fijos** del sistema SAAAF.

Funcionalidades:

- Listar activos con método GET.
- Registrar activos desde formulario HTML con método POST.
- Editar activos desde JSP.
- Eliminar activos desde servlet.
- Consultar indicadores en dashboard.
- Conectar con base de datos MySQL usando JDBC.

## Pasos de ejecución

1. Crear base de datos ejecutando `database/saaaf_web.sql`.
2. Ajustar usuario y clave en `ConexionJDBC.java`.
3. Compilar el proyecto con Maven:
   ```bash
   mvn clean package
   ```
4. Desplegar el archivo `target/saaaf-web.war` en Apache Tomcat 9.
5. Abrir en navegador:
   ```text
   http://localhost:8080/saaaf-web/
   ```

## Versionamiento

Los comandos se encuentran en `git_comandos.txt`.
El enlace del repositorio se debe registrar en `enlace_repositorio.txt`.
