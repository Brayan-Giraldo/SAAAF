document.addEventListener('DOMContentLoaded', function () {
    const fecha = document.querySelector('input[type="date"]');
    if (fecha && !fecha.value) {
        fecha.value = new Date().toISOString().split('T')[0];
    }
});
