CREATE DATABASE IF NOT EXISTS saaaf_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE saaaf_db;

DROP TABLE IF EXISTS activos;

CREATE TABLE activos (
    id_activo INT AUTO_INCREMENT PRIMARY KEY,
    codigo_activo VARCHAR(30) NOT NULL UNIQUE,
    nombre_activo VARCHAR(120) NOT NULL,
    tipo_activo VARCHAR(60) NOT NULL,
    area VARCHAR(80) NOT NULL,
    responsable VARCHAR(100),
    estado ENUM('Disponible','Asignado','Mantenimiento','Baja') NOT NULL DEFAULT 'Disponible',
    fecha_registro DATE NOT NULL,
    observaciones VARCHAR(255),
    CONSTRAINT chk_codigo_activo CHECK (CHAR_LENGTH(codigo_activo) >= 3)
);

INSERT INTO activos (codigo_activo, nombre_activo, tipo_activo, area, responsable, estado, fecha_registro, observaciones) VALUES
('ACT-001', 'Laptop Dell Inspiron', 'Equipo TI', 'Tecnologia', 'Carlos Mendez', 'Asignado', '2026-01-15', 'Equipo asignado a usuario administrativo'),
('ACT-002', 'Proyector Epson EB', 'Equipo AV', 'Ventas', 'Jorge Ruiz', 'Disponible', '2026-02-10', 'Disponible para sala de juntas'),
('ACT-003', 'Impresora HP LaserJet', 'Equipo TI', 'Administracion', 'Laura Gomez', 'Mantenimiento', '2026-03-05', 'Requiere revision preventiva');
